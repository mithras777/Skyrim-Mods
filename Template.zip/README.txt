New Skyrim SKSE plugin
Copyright (C) 2025-2026 Mithras666.

The original source code is licensed under the GNU General Public License, version 3 or (at your option) any later version. It is provided without any warranty. The full, unmodified license text is in LICENSE.txt. Official GPL-3.0 text: https://www.gnu.org/licenses/gpl-3.0.html.

Set MOD_SOURCE_URL in project.cmake before publishing so the packaged README.txt links to the public corresponding source. The pinned CommonLibSSE-NG license and exceptions, dependency lock, and third-party notices are included under licenses/.